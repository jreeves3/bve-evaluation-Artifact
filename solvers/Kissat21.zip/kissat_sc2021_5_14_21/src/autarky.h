#ifndef _autarky_h_INCLUDED
#define _autarky_h_INCLUDED

struct kissat;

void kissat_autarky (struct kissat *, char type);

#endif
