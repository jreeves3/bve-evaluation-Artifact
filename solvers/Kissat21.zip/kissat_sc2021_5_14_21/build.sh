#!/bin/sh

./configure && make

